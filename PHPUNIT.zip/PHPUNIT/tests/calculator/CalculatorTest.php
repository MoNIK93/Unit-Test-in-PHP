<?php
use PHPUnit\Framework\TestCase;

class CalculatorTest extends TestCase
{
    public function testAddOperands()
    {
        $calculator = new \App\Calculator;
        $calculator->setOperands([4, 6]);
        $this->assertEquals(10, $calculator->add());
    }
}